# Fresh Fold Altoona — Image Optimization and Local Search Kit
Prepared: November 1, 2026. 18 original uploaded assets processed.

## Deliverables
- 01_Google_Business_square_1080 — 1080 x 1080 JPEGs with embedded EXIF title, description, credit and keywords. Files are optimized and under Google's 5 MB photo limit. **NOT ALL are approved to publish**.
- 02_Instagram_Facebook_feed_1080x1350 — 4:5 JPEGs. Full source artwork remains visible; no promotion copy is cropped.
- 03_Stories_1080x1920 — 9:16 JPEGs, with full square flyer displayed in center against a blurred border. Text may be small; consider story-specific redesign before posting.
- 04_Website_WebP_1200 — efficient 1200 x 1200 WebP images. They still need appropriate HTML alt text and contextual text.
- 05_Transparent_Logos — the two uploaded seasonal logos kept transparent; they are not evergreen business logos.
- 06_Metadata_and_Post_Captions — CSV/JSON master catalog with status for EVERY asset, posts, alt text, EXIF keywords, plus individual XMP sidecars.
- 07_Strategy_and_Instructions — SEO notes, sample metadata and JSON-LD.

## Urgent: do not publish every image as-is
The CURRENT PUBLIC WEBSITE has STANDARD laundry processing $1.89/lb, $3.80 base plus $1.75/round-trip mile on the main page, and active daily routes in Altoona and State College, weekly in Lock Haven, selected route-based towns. The pricing page has additional service tiers and discounts. Subscription page includes separate delivery rates, and some prices differ from the pricing page; reconcile the site internally first.

- $35 per bag through NOVEMBER 2: unverified flash offer, and the normal website uses by-the-pound pricing. Must confirm offer window and terms.
- 40% off second bag; $6 local delivery; 2+ bags get free delivery; $10 loyalty and $5 referral credits: not verified on public website.
- Christmas Eve/Day availability: do not promise holiday pickups without confirming staff, cutoff times and fulfillment.
- 5% community hero offer: verify eligibility, discount stacking and time period.
- Flyers mention ORBIT LOGISTICS, website mentions TNT DELIVERIES. Pick true public delivery brand and use consistently.
- A Sunday same-day pickup offer is in the artworks, but contact page currently says Sunday CLOSED. Resolve BEFORE posting.
- Heavy soil $25: public site mentions a potential charge for significant messes or safety hazards; confirm exact policy and notice wording.
- Some images depict generic/AI-styled laundromat facilities, family models and branded bags. Do NOT present such visuals as documentary photos of an actual physical laundry facility or team if they aren't.
- All flyers have a visible PHONE NUMBER. Google Business Profile POST policy discourages/forbids phone numbers in post content. Better to use a revised graphic without the printed number and the platform's verified "Call now" button. Standard photo upload rules also prefer realistic photographs; these illustrated promotional flyers work better as social ads or Google POST artwork after review.
- Files named HOLD/REVIEW are still supplied so you can revise and use them later, NOT to imply these offers are approved.

## Important on location metadata
No GPS latitude/longitude were embedded. We have no confirmed verifiable physical business coordinates, and a pickup/delivery service area is NOT one accurate coordinate. Geo-tagging photographs or adding unrelated locations has no documented ranking shortcut. For a service-area business, hide the street address on Google if customers do not visit the business there; specify real served towns/ZIP codes in profile settings. Do not claim storefront locations without staff and signage.

## Upload instructions
1. Open FULL_IMAGE_CATALOG.csv. Filter review_status to READY or appropriately scheduled REVIEW items. Obtain business-owner approval of price, hour and policy claims before posting.
2. For Google Business Profile, upload authentic images of your real laundry process, sanitized packing, delivery bags and service team in addition to any approved promotional artwork. Use JPEG from folder 01, but adjust artwork to remove phone number for Google Posts when necessary.
3. Add appropriate call/booking button linked to https://www.freshfoldaltoona.com/ and verify your official profile phone.
4. For Instagram/Facebook use folder 02 and edit its provided caption to mention ONLY an approved offer. For Stories use folder 03, ideally re-designing small printed text to be legible.
5. For website, use folder 04 with alt_text from CSV and surrounding relevant content. PNG from folder 05 where transparency is needed.
6. Never reuse a November 2 discount post after its expiry without explicitly renewing the promotion.

## Stronger ranking moves than geotagging
- Confirm and verify Google Business Profile ownership and category appropriate to REAL mobile laundry services; completely fill services, hours, booking, service areas, website and contact info.
- Collect authentic customer reviews after delivered orders. Respond naturally. Never purchase or fabricate reviews.
- Maintain consistent public business name and phone across legitimate local profiles/directories, and accurate service-area claims.
- Create useful original landing pages for Altoona, State College and Lock Haven that explain actual schedule, delivery fees, return time, FAQs, benefits and local testimonials. Avoid mass doorway pages for towns without active service.
- Site SEO: use short descriptive titles, unique helpful page text, accessible image alt text, internal linking, accurate canonicals, XML sitemap, Google Search Console, and supported structured data.
- Speed: optimize hero images, use WebP on website and lazy-load non-critical images; do not lazy-load the most important above-the-fold visual.
- AI visibility: answer specific questions clearly (price per pound, service area ZIP, how pickup works, turnaround, detergent options, charges, cancellation, specialty bulky items) on crawlable pages; ensure facts match everywhere.
- Service coverage: Altoona and State College daily according to website, Lock Haven weekly, other communities route-based. Do not say 'everywhere' or claim same-day availability without confirmation.
- Rank position is NEVER guaranteed by filenames, image metadata, schema, or AI text.

## Source policy / website references (as checked 2026-11-01)
https://support.google.com/business/answer/6103862
https://support.google.com/business/answer/7213077
https://support.google.com/business/answer/7091
https://support.google.com/business/answer/9157481
https://developers.google.com/search/docs/appearance/google-images
https://developers.google.com/search/docs/appearance/structured-data/local-business
https://www.freshfoldaltoona.com/
https://www.freshfoldaltoona.com/pricing
https://www.freshfoldaltoona.com/subscriptions
https://www.freshfoldaltoona.com/service-areas
https://www.freshfoldaltoona.com/contact
